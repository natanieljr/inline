/** Automatically generated file. DO NOT MODIFY */
package com.srt.appguard.standalone.monitor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}