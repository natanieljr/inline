package com.srt.appguard.axml.io;

public interface AXmlStream {

	public static final int UINT_32_LENGTH_MASK = 1 << 16;
	public static final int UINT_16_LENGTH_MASK = 1 << 8;
}
