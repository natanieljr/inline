#ifndef _Included_instrumentation_h
#define _Included_instrumentation_h

#include <jni.h>

jmethodID redirectMethod(jmethodID methodId, jint guardsPtr, jint guardsIdx);

jmethodID lookupMethod(JNIEnv* env, jclass clazz, jstring methodName, jstring signature, int isStatic);

void unboxArguments(JNIEnv *env, jint methodPtr, jobjectArray args, jvalue nativeArgs[], jint length);

#endif
