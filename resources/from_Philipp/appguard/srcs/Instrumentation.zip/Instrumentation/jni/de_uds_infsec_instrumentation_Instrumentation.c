#include <jni.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>

#include "instrumentation.h"
#include "dalvik/dalvik.h"
#include "utils/log.h"

#define ARG_BUFFER_SIZE 64

JNIEXPORT jint JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_redirectMethodNative(JNIEnv* env, jclass _clazz,
		jclass clazz, jstring methodName, jstring prototype,
		jint guardsPtr, jint guardsIdx) {

	jmethodID methodId = lookupMethod(env, clazz, methodName, prototype, 0);
	if (methodId == NULL) {
		return (jint) NULL;
	}

	return (jint) redirectMethod(methodId, guardsPtr, guardsIdx);
}

JNIEXPORT jint JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_redirectStaticMethodNative(JNIEnv* env, jclass _clazz,
		jclass clazz, jstring methodName, jstring prototype,
		jint guardsPtr, jint guardsIdx) {

	jmethodID methodId = lookupMethod(env, clazz, methodName, prototype, 1);
	if (methodId == NULL) {
		return (jint) NULL;
	}

	return (jint) redirectMethod(methodId, guardsPtr, guardsIdx);
}


JNIEXPORT void JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callVoidMethod
  (JNIEnv *env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	(*env)->CallNonvirtualVoidMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jbyte JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callByteMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualByteMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jshort JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callShortMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualShortMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jint JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callIntMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualIntMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jlong JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callLongMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualLongMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jfloat JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callFloatMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualFloatMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jdouble JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callDoubleMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualDoubleMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jboolean JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callBooleanMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualBooleanMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jchar JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callCharMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualCharMethodA(env, _this, _class, methodId, nativeArgs);
}

JNIEXPORT jobject JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callObjectMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jobject _this, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;
	jclass _class = (*env)->GetObjectClass(env, _this);

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallNonvirtualObjectMethodA(env, _this, _class, methodId, nativeArgs);
}


JNIEXPORT void JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticVoidMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	(*env)->CallStaticVoidMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jbyte JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticByteMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticByteMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jshort JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticShortMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticShortMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jint JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticIntMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticIntMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jlong JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticLongMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticLongMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jfloat JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticFloatMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticFloatMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jdouble JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticDoubleMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticDoubleMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jboolean JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticBooleanMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticBooleanMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jchar JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticCharMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticCharMethodA(env, _class, methodId, nativeArgs);
}

JNIEXPORT jobject JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_callStaticObjectMethod
  (JNIEnv* env, jclass clazz, jint methodPtr, jclass _class, jobjectArray args) {
	jmethodID methodId = (jmethodID) methodPtr;

	jint length = (*env)->GetArrayLength(env, args);
	jvalue nativeArgs[ARG_BUFFER_SIZE];
	unboxArguments(env, methodPtr, args, nativeArgs, length);

	return (*env)->CallStaticObjectMethodA(env, _class, methodId, nativeArgs);
}





////////////////////////////////////////////////////////////////////////////////////////
// XXX TEST
////////////////////////////////////////////////////////////////////////////////////////

JNIEXPORT void JNICALL Java_de_uds_infsec_instrumentation_Instrumentation_removeAbstractModifier
  (JNIEnv* env, jclass clazz, jclass _class) {
	jmethodID methodId = (*env)->GetMethodID(env, _class, "onTransact", "(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z");

	if (methodId == NULL) {
		(*env)->ExceptionClear(env);
		LOGW("onTransact() method not found!");
	}

	Method* method = (Method*) methodId;
	ClassObject* cls = method->clazz;
	LOGI("Got class object = %p, accessFlags = %x", cls, cls->accessFlags);

	cls->accessFlags &= ~ACC_ABSTRACT;

	LOGI("Got class object = %p, accessFlags = %x", cls, cls->accessFlags);
}
