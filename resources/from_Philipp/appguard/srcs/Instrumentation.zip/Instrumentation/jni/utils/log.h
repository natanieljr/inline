#include <android/log.h>

#ifndef _Included_log_h
#define _Included_log_h

#define  _LOG_TAG    "Instrumentation"
#define  LOGV(...)  __android_log_print(ANDROID_LOG_VERBOSE,_LOG_TAG,__VA_ARGS__)
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,_LOG_TAG,__VA_ARGS__)
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,_LOG_TAG,__VA_ARGS__)
#define  LOGW(...)  __android_log_print(ANDROID_LOG_WARN,_LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,_LOG_TAG,__VA_ARGS__)

#endif /* _Included_log_h */
