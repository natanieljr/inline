/** Automatically generated file. DO NOT MODIFY */
package de.uds.infsec.instrumentation.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}