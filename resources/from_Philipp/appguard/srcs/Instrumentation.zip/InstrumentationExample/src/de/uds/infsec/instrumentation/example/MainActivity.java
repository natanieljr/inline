package de.uds.infsec.instrumentation.example;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.app.Activity;
import android.os.Bundle;
import de.uds.infsec.instrumentation.Instrumentation;
import de.uds.infsec.instrumentation.annotation.Redirect;

public class MainActivity extends Activity {

	private static boolean instrumented = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		if (instrumented) return;
		Instrumentation.processClass(MainActivity.class);
		instrumented = true;
		
		foo();
		foo2();
	}

	
	private static void foo() {
		System.out.println("foo() called");
	}

	private void foo2() {
		System.out.println("MainActivity.foo2()");
	}

	@Redirect("de.uds.infsec.instrumentation.example.MainActivity->foo")
	public static void bar() {
		System.out.println("bar() called");
	}

	@Redirect("de.uds.infsec.instrumentation.example.MainActivity->foo2")
	public static void bar2(MainActivity _this) {
		System.out.println("bar2() called");
	}

	
	// This method is junk and never called!
    // It just contains some symbols which we need to create trampolines
    // for methods in the app's dex file (which is the one we're in).
    public void ___() {
         try {
               Object[] arr = new Object[0];
               Method m = arr.getClass().getMethod("toString");
               m.invoke(arr);
         } catch (InvocationTargetException e) {
               e.getCause();
         } catch (Exception e) {
               e.getCause();
         }
         
         // boxing/unboxing methods
         Byte.valueOf((byte) 42).byteValue();
         Character.valueOf((char) 42).charValue();
         Double.valueOf((double) 42).doubleValue();
         Float.valueOf((float) 42).floatValue();
         Integer.valueOf((int) 42).intValue();
         Long.valueOf((long) 42).longValue();
         Short.valueOf((short) 42).shortValue();
         Boolean.valueOf(false).booleanValue();
    }
}
