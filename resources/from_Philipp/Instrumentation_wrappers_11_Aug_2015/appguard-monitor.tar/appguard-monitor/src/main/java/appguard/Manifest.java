package appguard;

public class Manifest {

	public static class permission {
		public final static String ACCESS_MEDIA_STORAGE = "appguard.permission.ACCESS_MEDIA_STORAGE";
	}
	
	public static class permissionGroup {
		public final static String APPGUARD = "appguard.permission-group.APPGUARD";
	}
}
